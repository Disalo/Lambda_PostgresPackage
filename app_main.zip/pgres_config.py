#config file containing credentials for RDS MySQL instance
db_username = "rdsbay"
db_password = "rdsforbayer"
db_name = "ExampleDB"