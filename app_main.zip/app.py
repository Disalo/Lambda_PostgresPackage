import psycopg2
import json
import pgres_config
import logging
import sys

logger = logging.getLogger()
logger.setLevel(logging.INFO)

host = "postgresforlambdatest.cpysadcfqd9i.eu-north-1.rds.amazonaws.com"
username = pgres_config.db_username
password = pgres_config.db_password
database = pgres_config.db_name

conn = psycopg2.connect(
    host = host,
    database = database,
    user = username,
    password = password
)

def lambda_handler(event, context):
    item_count = 0
    #cur = conn.cursor(cursor_factory = RealDictCursor)
    with conn.cursor() as cur:
        cur.execute("create table Employee ( EmpID  int NOT NULL, Name varchar(255) NOT NULL, PRIMARY KEY (EmpID))")
        cur.execute('insert into Employee (EmpID, Name) values(1, "Joe")')
        cur.execute('insert into Employee (EmpID, Name) values(2, "Bob")')
        cur.execute('insert into Employee (EmpID, Name) values(3, "Mary")')
        conn.commit()
        cur.execute("select * from Employee")
        for row in cur:
            item_count += 1
            logger.info(row)
    conn.commit()

    return "Added %d items from RDS MySQL table" %(item_count)